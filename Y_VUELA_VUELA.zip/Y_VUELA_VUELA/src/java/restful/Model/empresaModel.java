
package restful.Model;

import java.util.ArrayList;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class empresaModel {
    private String Id_vuelo;
    private String ciudad_salida;
    private String ciudad_llegada;
    private String fecha_salida;
    private String frecuencia;
    private float precio_ruta;
    private String tiempo_estimado;

    public empresaModel() {
    }

    public empresaModel(String Id_vuelo, String ciudad_salidad, String ciudad_llegada, String fecha_salida, String frecuencia, float precio_ruta, String tiempo_estimado) {
        this.Id_vuelo = Id_vuelo;
        this.ciudad_salida = ciudad_salida;
        this.ciudad_llegada = ciudad_llegada;
        this.fecha_salida = fecha_salida;
        this.frecuencia = frecuencia;
        this.precio_ruta = precio_ruta;
        this.tiempo_estimado = tiempo_estimado;
    }

    public String getId_vuelo() {
        return Id_vuelo;
    }

    public void setId_vuelo(String Id_vuelo) {
        this.Id_vuelo = Id_vuelo;
    }

    public String getCiudad_salida() {
        return ciudad_salida;
    }

    public void setCiudad_salida(String ciudad_salida) {
        this.ciudad_salida = ciudad_salida;
    }

    public String getCiudad_llegada() {
        return ciudad_llegada;
    }

    public void setCiudad_llegada(String ciudad_llegada) {
        this.ciudad_llegada = ciudad_llegada;
    }

    public String getFecha_salida() {
        return fecha_salida;
    }

    public void setFecha_salida(String fecha_salida) {
        this.fecha_salida = fecha_salida;
    }

    public String getFrecuencia() {
        return frecuencia;
    }

    public void setFrecuencia(String frecuencia) {
        this.frecuencia = frecuencia;
    }

    public float getPrecio_ruta() {
        return precio_ruta;
    }

    public void setPrecio_ruta(float precio_ruta) {
        this.precio_ruta = precio_ruta;
    }

    public String getTiempo_estimado() {
        return tiempo_estimado;
    }

    public void setTiempo_estimado(String tiempo_estimado) {
        this.tiempo_estimado = tiempo_estimado;
    }
    
    
    
}


