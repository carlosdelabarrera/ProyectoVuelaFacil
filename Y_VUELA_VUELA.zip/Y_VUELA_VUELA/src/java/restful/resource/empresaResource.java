
package restful.resource;

import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import restful.Model.empresaModel;
import restful.service.empresaService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.sql.SQLException;
import javax.ws.rs.DELETE;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;

@Path("empresa")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public class empresaResource {
    
    empresaService servicio = new empresaService();
    
    @GET
    public ArrayList<empresaModel> getEmpresa() throws SQLException{
        return servicio.getEmpresa(); 
    }
    
    @Path("/vuelo") 
    @GET 
    public empresaModel getVuelo (@PathParam("vuelo") int id) {
        return servicio.getVuelo(id);
    }
    
    
    
    
    @POST 
    public empresaModel addVuelo (String JSON) throws SQLException {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        empresaModel vuelo = gson.fromJson(JSON, empresaModel.class);
        return  servicio.addVuelo(vuelo);
    }
    
    
    
    
    @PUT
    public empresaModel updateVuelo (String JSON) {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        
        empresaModel upVuelo =  gson.fromJson(JSON, empresaModel.class);
        return servicio.updateVuelo(upVuelo);
    }
    
    
    
    @DELETE
    @Path("/{vueloID}")
    public String deleteVuelo(@PathParam("vueloID")int id) {
        return servicio.deleteVuelo(id);
    }
    
}
