
package restful.Model;

import java.util.ArrayList;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class agenciaModel {
    
    private int Id_agencia;
    private String Nombre;
    private String Ubicacion;
    private String Telefono;

    public agenciaModel() {
    }

    public agenciaModel(int Id_agencia, String Nombre, String Ubicacion, String Telefono) {
        this.Id_agencia = Id_agencia;
        this.Nombre = Nombre;
        this.Ubicacion = Ubicacion;
        this.Telefono = Telefono;
    }

    public int getId_agencia() {
        return Id_agencia;
    }

    public void setId_agencia(int Id_agencia) {
        this.Id_agencia = Id_agencia;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getUbicacion() {
        return Ubicacion;
    }

    public void setUbicacion(String Ubicacion) {
        this.Ubicacion = Ubicacion;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }
    
    
}
