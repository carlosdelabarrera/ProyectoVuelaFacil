
package restful.Model;

import java.util.ArrayList;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement

public class facturaModel {
    private int Id_factura;
    private int Id_vuelo;
    private int Id_agencia;
    private int CC;
    private String fecha;

    public facturaModel() {
    }

    public facturaModel(int Id_factura, int Id_vuelo, int Id_agencia, int CC, String fecha) {
        this.Id_factura = Id_factura;
        this.Id_vuelo = Id_vuelo;
        this.Id_agencia = Id_agencia;
        this.CC = CC;
        this.fecha = fecha;
    }

    public int getId_factura() {
        return Id_factura;
    }

    public void setId_factura(int Id_factura) {
        this.Id_factura = Id_factura;
    }

    public int getId_vuelo() {
        return Id_vuelo;
    }

    public void setId_vuelo(int Id_vuelo) {
        this.Id_vuelo = Id_vuelo;
    }

    public int getId_agencia() {
        return Id_agencia;
    }

    public void setId_agencia(int Id_agencia) {
        this.Id_agencia = Id_agencia;
    }

    public int getCC() {
        return CC;
    }

    public void setCC(int CC) {
        this.CC = CC;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    
    

    
    
    
   
}
