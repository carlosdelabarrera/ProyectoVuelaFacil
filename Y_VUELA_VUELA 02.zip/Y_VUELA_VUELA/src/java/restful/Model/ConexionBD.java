/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restful.Model;

import java.sql.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexionBD {
    
        
    

    // Configuracion de la conexion a la base de datos
    private String DB_driver = "";
    private String url = "";
    //private String db = "";
    //private String host = "";
    private String username = "";
    private String password = "";
    public Connection con = null;
    private Statement stmt = null;
    //private PreparedStatement pstmt = null;
    private ResultSet rs = null;
    //private boolean local;


    //Constructor sin parmetros
    public ConexionBD() {
    DB_driver = "com.mysql.cj.jdbc.Driver";
    username = "root";
    password = "EagcErioran26";
    url = "jdbc:mysql://127.0.0.1:3306/base_vuelafacil_02";

    try {
    //Asignacin del Driver
    Class.forName(DB_driver);
    } catch (ClassNotFoundException ex) {
    Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
    System.exit(0);
    }


    try {
    // Realizar la conexion
    con = DriverManager.getConnection(url, username, password);

    System.out.println("conectado");
    } catch (SQLException ex) {
    Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
    System.exit(0);
    }
    // Realizar la conexin
    // Realizar la conexin
    }


    //Retornar la conexin
    public Connection getConnection() {
    return con;
    }



    //Cerrar la conexin
    //public void closeConnection(Connection con) {
    //if (con != null) {
    //try {
    //con.close();
    //} catch (SQLException ex) {
    //Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
    //}
    //}
    //}


    // Mtodo que devuelve un ResultSet de una consulta (tratamiento de SELECT)
    public ResultSet consultarBD(String sentencia) {
    try {
    stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
    ResultSet.CONCUR_READ_ONLY);
    rs = stmt.executeQuery(sentencia);
    } catch (SQLException sqlex) {
    } catch (RuntimeException rex) {
    } catch (Exception ex) {
    }
    return rs;
    }


    // Mtodo que realiza un INSERT y devuelve TRUE si la operacin fue existosa
    public boolean insertarBD(String sentencia) {
    try {
    stmt = con.createStatement();
    stmt.execute(sentencia);
    } catch (SQLException | RuntimeException sqlex) {
    System.out.println("ERROR RUTINA: " + sqlex);
    return false;
    }
    return true;
    }


    public boolean borrarBD(String sentencia) {
    try {
    stmt = con.createStatement();
    stmt.execute(sentencia);
    } catch (SQLException | RuntimeException sqlex) {
    System.out.println("ERROR RUTINA: " + sqlex);
    return false;
    }
    return true;
    }


    // Mtodo que realiza una operacin como UPDATE, DELETE, CREATE TABLE, entre otras
    // y devuelve TRUE si la operacin fue existosa
    public boolean actualizarBD(String sentencia) {
    try {
    stmt = con.createStatement();
    stmt.executeUpdate(sentencia);
    } catch (SQLException | RuntimeException sqlex) {
    System.out.println("ERROR RUTINA: " + sqlex);
    return false;
    }
    return true;
    }


    public boolean setAutoCommitBD(boolean parametro) {
    try {
    con.setAutoCommit(parametro);
    } catch (SQLException sqlex) {
    System.out.println("Error al configurar el autoCommit " + sqlex.getMessage());
    return false;
    }
    return true;
    }






    //public void cerrar_Conexion() {
    //closeConnection(con);
    //}
    public boolean commitBD() {
    try {
    con.commit();
    return true;
    } catch (SQLException sqlex) {
    System.out.println("Error al hacer commit " + sqlex.getMessage());
    return false;
    }
    }
    
    public boolean rollbackBD() {
    try {
    con.rollback();
    return true;
    } catch (SQLException sqlex) {
    System.out.println("Error al hacer rollback " + sqlex.getMessage());
    return false;
    }
    }
    
    //public static void main(String[] args) {
    //ConexionBD b = new ConexionBD();
    //b.cerrarConexion();
    //}








//    public static void main(String[] args) {
//        
//            // TODO code application logic here
//            
//            Scanner consola = new Scanner(System.in);
//            
//            // definicion de los parametros de conexion
//            String usuario, clave, url, driver, sql;
//            // declaracion de variable para la conexion y el statemant ( ejecucion del sql)
//            Connection con = null;
//            Statement stmt = null;
//            ResultSet sr ;
//            
//            usuario = "root";
//            clave = "EagcErioran26";
//            url = "jdbc:mysql://127.0.0.1:3306/base_vuelafacil_01";
//            driver = "com.mysql.cj.jdbc.Driver";
//            try {
//            //Primera Parte: Conexión
//            //Primera partes- Punto 1) Activar el direves
//            Class.forName(driver);
//        } catch (ClassNotFoundException ex) {
//            System.out.println("Error en el Driver");
//            System.exit(0);
//        }
//        try {
//            //Primera parte - Punto 2)Realizar la conexión
//            con = DriverManager.getConnection(url, usuario, clave);
//        } catch (SQLException ex) {
//            System.out.println("Error en la conexión");
//            System.exit(0);
//        }
//        
//        try {
//            //Segunda perte=> Statement
//            stmt = con.createStatement();
//        } catch (SQLException ex) {
//            System.out.println("Error en en el Statement");
//            System.exit(0);
//        }
//        
//        
//        
//        
//        
//    }

    

}


