
package restful.Model;

import java.util.ArrayList;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement

public class usuarioModel {
    private int CC;
    private String Nombre;
    private String Edad;
    private String Correo;
    private String telefono;

    public usuarioModel() {
    }

    public usuarioModel(int CC, String Nombre, String Edad, String Correo,  String telefono) {
        this.CC = CC;
        this.Nombre = Nombre;
        this.Edad = Edad;
        this.Correo = Correo;
        this.telefono = telefono;
    }

    public int getCC() {
        return CC;
    }

    public void setCC(int CC) {
        this.CC = CC;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getEdad() {
        return Edad;
    }

    public void setEdad(String Edad) {
        this.Edad = Edad;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }


    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    
    
    
}
