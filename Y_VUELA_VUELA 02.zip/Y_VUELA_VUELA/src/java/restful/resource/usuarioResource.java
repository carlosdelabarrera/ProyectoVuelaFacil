package restful.resource;

import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import restful.Model.usuarioModel;
import restful.service.usuarioService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.sql.SQLException;
import javax.ws.rs.DELETE;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;

@Path("usuario")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public class usuarioResource {
    
    usuarioService servicio = new usuarioService();
    
    @GET
    public ArrayList<usuarioModel> getUsuario() throws SQLException{
         return servicio.getUsuario();
        
   }
    
    
    
    
    @Path("/{CC}") 
    @GET 
    public usuarioModel getUsuario (@PathParam("CC") int id) {
        return servicio.getUsuario(id);
    }
    
    
    
    
    
    
    @POST 
    public usuarioModel addUsuario (String JSON) throws SQLException {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        usuarioModel usuario = gson.fromJson(JSON, usuarioModel.class);
        return  servicio.addUsuario(usuario);
    }
    
    
    
    
    
    
    
    
   @PUT
    public usuarioModel updateUsuario (String JSON) {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        
        usuarioModel upUsuario =  gson.fromJson(JSON, usuarioModel.class);
        return servicio.updateUsuario(upUsuario);
    }
    
    
    
    
    
    @DELETE
    @Path("/{usuarioID}")
    public String deleteUsuario(@PathParam("usuarioID")String id) {
        return servicio.deleteUsuario(id);
    }
}
