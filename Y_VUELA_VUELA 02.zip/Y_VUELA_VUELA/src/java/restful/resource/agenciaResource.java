
package restful.resource;

import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import restful.Model.agenciaModel;
import restful.service.agenciaService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.sql.SQLException;
import javax.ws.rs.DELETE;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;

@Path("agencia")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public class agenciaResource {
    agenciaService servicio = new agenciaService();
    
    @GET
    public ArrayList<agenciaModel> getAgencia() throws SQLException{
        return servicio.getAgencia();  
}
    
    
    @Path("/{agencia}") 
    @GET 
    public agenciaModel getAgencia (@PathParam("agencia") int id) {
        return servicio.getAgencia(id);
    }
    
    
    
    
    
    
    
    
    @POST 
    public agenciaModel addAgencia (String JSON) throws SQLException {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        agenciaModel agencia = gson.fromJson(JSON, agenciaModel.class);
        return  servicio.addAgencia(agencia);
    }
    
    
    
    
    
    
    
    @PUT
    public agenciaModel updateAgencia (String JSON) {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        
        agenciaModel upAgencia =  gson.fromJson(JSON, agenciaModel.class);
        return servicio.updateAgencia(upAgencia);
    }
    
    
    
    
    
    @DELETE
    @Path("/{agenciaID}")
    public String deleteAgencia(@PathParam("agenciaID")String id) {
        return servicio.deleteAgencia(id);
    }
    
    
}
