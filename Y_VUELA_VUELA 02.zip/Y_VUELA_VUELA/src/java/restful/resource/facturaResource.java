
package restful.resource;

import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import restful.Model.facturaModel;
import restful.service.factutaService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.sql.SQLException;
import javax.ws.rs.DELETE;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;

@Path("factura")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public class facturaResource {
    
    factutaService servicio = new factutaService();
    
    @GET
    public ArrayList<facturaModel> getFactura() throws SQLException{
        return servicio.getFactura();
    }
    
    
    
    
    @Path("/{factura}") 
    @GET 
    public facturaModel getFactura(@PathParam("factura") int id) {
        return servicio.getFactura(id);
    }
    
    
    
    
    
    
    @POST 
    public facturaModel addFactura (String JSON) throws SQLException {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        facturaModel factura= gson.fromJson(JSON, facturaModel.class);
        return  servicio.addFactura(factura);
    }
    
    
    
    
    
    
    @PUT
    public facturaModel updateFactura (String JSON) {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        
        facturaModel upFactura =  gson.fromJson(JSON, facturaModel.class);
        return servicio.updateFactura(upFactura);
    }
    
    
    
    
    
    
    @DELETE
    @Path("/{facturaID}")
    public String deleteVuelo(@PathParam("facturaID")String id) {
        return servicio.deleteFactura(id);
    }
    
}
