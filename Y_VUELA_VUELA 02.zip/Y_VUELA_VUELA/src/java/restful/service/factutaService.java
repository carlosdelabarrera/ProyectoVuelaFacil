
package restful.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import restful.Model.facturaModel;
import restful.Model.ConexionBD;

public class factutaService {
    
    // busquedad general
    public ArrayList<facturaModel> getFactura() throws SQLException {
    ArrayList<facturaModel> lista = new ArrayList<>();
    ConexionBD con = new ConexionBD();
    String sql = "select * from factura";
    
    try {
        Statement stm = con.getConnection().createStatement();
        
       
        ResultSet rs = stm.executeQuery(sql);
        
        while (rs.next()) {
            facturaModel factura = new facturaModel();
            factura.setId_factura(rs.getInt("id_factura"));
            factura.setId_vuelo(rs.getInt("Id_vuelo"));
            factura.setId_agencia(rs.getInt("Id_agencia"));
            factura.setCC(rs.getInt("CC"));
            factura.setFecha(rs.getString("fecha"));
            
            lista.add(factura);
        }
        
    } catch (SQLException e) { 
    }
    
        return lista;
    }
    
    
    
    
    
    
     // busquedad individual.
    public facturaModel getFactura (int id)  {
    facturaModel factura = new facturaModel();
    ConexionBD con = new ConexionBD();
    String sql = "select * from factura where Id_factura = ?";
    
    try {
        PreparedStatement stm = con.getConnection().prepareStatement(sql);
        stm.setInt(1, id);
        ResultSet rs = stm.executeQuery();
        
        
        while (rs.next()) {
                    
            factura.setId_factura(rs.getInt("id_factura"));
            factura.setId_vuelo(rs.getInt("Id_vuelo"));
            factura.setId_agencia(rs.getInt("Id_agencia"));
            factura.setCC(rs.getInt("CC"));
            factura.setFecha(rs.getString("fecha"));
           
        }
         
    } catch (SQLException e) { 
         System.out.println(e);
    }
        return factura;
    }
    
    
    
    
    
    
    public facturaModel addFactura (facturaModel factura) throws SQLException {
        ConexionBD con = new ConexionBD();
        String sql = "insert into factura (id_factura,Id_vuelo,Id_agencia,CC,fecha";
        sql = sql + "values (?,?,?,?,?)";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            //PreparedStatement stm = con.
            stm.setInt(1, factura.getId_factura());
            stm.setInt(2, factura.getId_vuelo());
            stm.setInt(3, factura.getId_agencia());
            stm.setInt(4, factura.getCC());
            stm.setString(5, factura.getFecha());
            
            
            stm.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println(e);
            return  null; 
        }
        return factura;
    }
    
    
    
    
    
    
    public facturaModel updateFactura (facturaModel upFactura) {
        ConexionBD con = new ConexionBD();
        String sql = "update factura set Id_vuelo = ?,Id_agencia = ?,CC = ? ,fecha = ? where id_factura = ? ";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            
            stm.setInt(1, upFactura.getId_vuelo());
            stm.setInt(2, upFactura.getId_agencia());
            stm.setInt(3, upFactura.getCC());
            stm.setString(4, upFactura.getFecha());
            stm.setInt(5, upFactura.getId_factura());
            
            stm.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error al actualizar");
            return null;
        }
        return upFactura;
    }

    
    
    
    
    
    
    
    public String deleteFactura(String id){
        ConexionBD con = new ConexionBD();
        String sql = "delete from factura where Id_factura =? ";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            stm.setString(1, id);
            stm.executeQuery();
             
        } catch (SQLException e) {
            System.out.println("Error al aliminar ");
            return "{\"Accion\":\"Error\"}";
        }
        return  "{\"Accion\":\"resgistro borrado\"}";
        
    }
    
}
