
package restful.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import restful.Model.agenciaModel;
import restful.Model.ConexionBD;

public class agenciaService {
    
    // busquedad general
    public ArrayList<agenciaModel> getAgencia() throws SQLException {
    ArrayList<agenciaModel> lista = new ArrayList<>();
    ConexionBD con = new ConexionBD();
    String sql = "select * from agencia_de_viajes";
    
    try {
        Statement stm = con.getConnection().createStatement();
        
       
        ResultSet rs = stm.executeQuery(sql);
        
        while (rs.next()) {
            agenciaModel agencia = new agenciaModel();
            agencia.setId_agencia(rs.getInt("Id_agencia"));
            agencia.setNombre(rs.getString("Nombre"));
            agencia.setUbicacion(rs.getString("Ubicacion"));
            agencia.setTelefono(rs.getString("Telefono"));
            lista.add(agencia);
        }
        
    } catch (SQLException e) { 
    }
    
        return lista;
}
    
    
    
    
    // busquedad individual.
    public agenciaModel getAgencia (int id)  {
    agenciaModel agencia = new agenciaModel();
    ConexionBD con = new ConexionBD();
    String sql = "select * from agencia_de_viajes where Id_agencia = ?";
    
    try {
        PreparedStatement stm = con.getConnection().prepareStatement(sql);
        stm.setInt(1, id);
        ResultSet rs = stm.executeQuery();
        
        
        while (rs.next()) {
            
            agencia.setId_agencia(rs.getInt("Id_agencia"));
            agencia.setNombre(rs.getString("Nombre"));
            agencia.setUbicacion(rs.getString("Ubicacion"));
            agencia.setTelefono(rs.getString("Telefono"));
           
        }
         
    } catch (SQLException e) { 
         System.out.println(e);
    }
        return agencia;
    }
    
    
    
    
    
    
    
    
    public agenciaModel addAgencia (agenciaModel agencia) throws SQLException {
        ConexionBD con = new ConexionBD();
        String sql = "insert into agencia_de_viajes(Id_agencia,Nombre,Ubicacion,Telefono";
        sql = sql + "values (?,?,?,?)";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            
            stm.setInt(1, agencia.getId_agencia());
            stm.setString(2, agencia.getNombre());
            stm.setString(3, agencia.getUbicacion());
            stm.setString(4, agencia.getTelefono());
            
            stm.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println(e);
            return  null; 
        }
        return agencia;
    }
    
    
    
    
    
    
    
    
    public agenciaModel updateAgencia (agenciaModel upAgencia) {
        ConexionBD con = new ConexionBD();
        String sql = "update agencia_de_viajes set Nombre=?,Ubicacion=?,Telefono=? where Id_agencia=? ";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            
            stm.setString(1, upAgencia.getNombre());
            stm.setString(2, upAgencia.getUbicacion());
            stm.setString(3, upAgencia.getTelefono());
            stm.setInt(4, upAgencia.getId_agencia());
            
            stm.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println("Error al actualizar");
            return null;
        }
        return upAgencia;
    }

    
    
    
    
    
    
    
    public String deleteAgencia(String id){
        ConexionBD con = new ConexionBD();
        String sql = "delete from agencia_de_viajes where Id_vuelo =? ";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            stm.setString(1, id);
            stm.executeQuery();
             
        } catch (SQLException e) {
            System.out.println("Error al aliminar ");
            return "{\"Accion\":\"Error\"}";
        }
        return  "{\"Accion\":\"resgistro borrado\"}";
        
    }
    
    
}