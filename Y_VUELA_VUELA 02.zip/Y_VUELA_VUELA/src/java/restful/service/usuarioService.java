
package restful.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import restful.Model.usuarioModel;
import restful.Model.ConexionBD;

public class usuarioService {
    
    // busquedad general.
    public ArrayList<usuarioModel> getUsuario() throws SQLException {
    ArrayList<usuarioModel> lista = new ArrayList<>();
    ConexionBD con = new ConexionBD();
    String sql = "select * from usuario_agencia";
    
    try {
        Statement stm = con.getConnection().createStatement();
        
       
        ResultSet rs = stm.executeQuery(sql);
        
        while (rs.next()) {
            usuarioModel usuario = new usuarioModel();
            usuario.setCC(rs.getInt("CC"));
            usuario.setNombre(rs.getString("Nombre"));
            usuario.setEdad(rs.getString("Edad"));
            usuario.setCorreo(rs.getString("Correo"));
            usuario.setTelefono(rs.getString("telefono"));
            lista.add(usuario);
        }
        
    } catch (SQLException e) { 
    }
    
        return lista;
    }
   
    
    
    
    
    
    
    // busquedad individual.
    public usuarioModel getUsuario (int id)  {
    usuarioModel usuario = new usuarioModel();
    ConexionBD con = new ConexionBD();
    String sql = "select * from usuario_agencia where CC = ?";
    
    try {
        PreparedStatement stm = con.getConnection().prepareStatement(sql);
        stm.setInt(1, id);
        ResultSet rs = stm.executeQuery();
        
        
        while (rs.next()) {
            
            usuario.setCC(rs.getInt("CC"));
            usuario.setNombre(rs.getString("Nombre"));
            usuario.setEdad(rs.getString("Edad"));
            usuario.setCorreo(rs.getString("Correo"));
            usuario.setTelefono(rs.getString("telefono"));
           
        }
         
    } catch (SQLException e) { 
         System.out.println(e);
    }
        return usuario;
    }
    
    
    
    
    
    
    
    public usuarioModel addUsuario (usuarioModel usuario) throws SQLException {
        ConexionBD con = new ConexionBD();
        String sql = "insert into usuario_agencia (CC, Nombre, Edad, Correo, telefono ";
        sql = sql + "values (?,?,?,?,?)";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            
            stm.setInt(1, usuario.getCC());
            stm.setString(2, usuario.getNombre());
            stm.setString(3, usuario.getEdad());
            stm.setString(4, usuario.getCorreo());
            stm.setString(5, usuario.getTelefono());
          
            
            stm.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println(e);
            return  null; 
        }
        return usuario;
    }
    
    
    
    
    
    
    public usuarioModel updateUsuario (usuarioModel upUsuario) {
        ConexionBD con = new ConexionBD();
        String sql = "update usuario_agencia set  Nombre =?, Edad =?, Correo =?, telefono =? where  CC = ?";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            
            stm.setString(1, upUsuario.getNombre());
            stm.setString(2, upUsuario.getEdad());
            stm.setString(3, upUsuario.getCorreo());
            stm.setString(4, upUsuario.getTelefono());
            stm.setInt(5, upUsuario.getCC());
            
            stm.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println("Error al actualizar");
            return null;
        }
        return upUsuario;
    }
    
    
    
    
    
    
    public String deleteUsuario(String id){
        ConexionBD con = new ConexionBD();
        String sql = "delete from usuario_agencia where CC =? ";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            stm.setString(1, id);
            stm.executeQuery();
             
        } catch (SQLException e) {
            System.out.println("Error al aliminar ");
            return "{\"Accion\":\"Error\"}";
        }
        return  "{\"Accion\":\"resgistro borrado\"}";
        
    }
    
}
