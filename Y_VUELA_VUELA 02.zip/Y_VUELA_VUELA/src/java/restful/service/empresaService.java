
package restful.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import restful.Model.empresaModel;
import restful.Model.ConexionBD;

public class empresaService {
    // busquedad general
    public ArrayList<empresaModel> getEmpresa() throws SQLException {
    ArrayList<empresaModel> lista = new ArrayList<>();
    ConexionBD con = new ConexionBD();
    String sql = "select * from empresa_de_aviacion";
    
    try {
        Statement stm = con.getConnection().createStatement();
        
       
        ResultSet rs = stm.executeQuery(sql);
        
        while (rs.next()) {
            empresaModel empresa = new empresaModel();
            empresa.setId_vuelo(rs.getInt("Id_vuelo"));
            empresa.setCiudad_salida(rs.getString("ciudad_salida"));
            empresa.setCiudad_llegada(rs.getString("ciudad_llegada"));
            empresa.setFecha_salida(rs.getNString("fecha_salida"));
            empresa.setFrecuencia(rs.getString("frecuencia"));
            empresa.setPrecio_ruta(rs.getFloat("precio_ruta"));
            empresa.setTiempo_estimado(rs.getString("tiempo_estimado"));
            lista.add(empresa);
        }
        
    } catch (SQLException e) { 
    }
    
        return lista;
    }
    
    
    
    
    // busquedad individual.
    public empresaModel getVuelo (int id)  {
    empresaModel vuelo = new empresaModel();
    ConexionBD con = new ConexionBD();
    String sql = "select * from empresa_de_aviacion where Id_vuelo = ?";
    
    try {
        PreparedStatement stm = con.getConnection().prepareStatement(sql);
        stm.setInt(1, id);
        ResultSet rs = stm.executeQuery();
        
        
        while (rs.next()) {
            
            vuelo.setId_vuelo(rs.getInt("Id_vuelo"));
            vuelo.setCiudad_salida(rs.getString("ciudad_salida"));
            vuelo.setCiudad_llegada(rs.getString("ciudad_llegada"));
            vuelo.setFecha_salida(rs.getNString("fecha_salida"));
            vuelo.setFrecuencia(rs.getString("frecuencia"));
            vuelo.setPrecio_ruta(rs.getFloat("precio_ruta"));
            vuelo.setTiempo_estimado(rs.getString("tiempo_estimado"));
           
        }
         
    } catch (SQLException e) { 
         System.out.println(e);
    }
        return vuelo;
    } 
    
    
    
    
    // BUSQUEDA POR PRECIOS MENORES O IGUALES A: 
//    public ArrayList<empresaModel> getPrecio(int precio) throws SQLException {
//    ArrayList<empresaModel> lista = new ArrayList<>();
//    
//    ConexionBD con = new ConexionBD();
//    String sql = "select * from empresa_de_aviacion where precio_ruta <= ?";
//    
//    try {
//        Statement stm = con.getConnection().createStatement();
//        
//       
//        ResultSet rs = stm.executeQuery(sql);
//        
//        while (rs.next()) {
//            empresaModel precios = new empresaModel();
//            precios.setId_vuelo(rs.getString("Id_vuelo"));
//            precios.setCiudad_salida(rs.getString("ciudad_salida"));
//            precios.setCiudad_llegada(rs.getString("ciudad_llegada"));
//            precios.setFecha_salida(rs.getNString("fecha_salida"));
//            precios.setFrecuencia(rs.getString("frecuencia"));
//            precios.setPrecio_ruta(rs.getFloat("precio_ruta"));
//            precios.setTiempo_estimado(rs.getString("tiempo_estimado"));
//            lista.add(precios);
//        }
//        
//    } catch (SQLException e) { 
//    }
//    
//        return lista;
//    }
    
    
    
    
    
    
    
    
    
    
    
    public empresaModel addVuelo (empresaModel vuelo) throws SQLException {
        ConexionBD con = new ConexionBD();
        String sql = "insert into empresa_de_aviacion(Id_vuelo,ciudad_salida,ciudad_llegada,fecha_salida,frecuencia,precio_ruta,tiempo_estimado";
        sql = sql + "values (?,?,?,?,?,?,?)";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            
            stm.setInt(1, vuelo.getId_vuelo());
            stm.setString(2, vuelo.getCiudad_salida());
            stm.setString(3, vuelo.getCiudad_llegada());
            stm.setString(4, vuelo.getFecha_salida());
            stm.setString(5, vuelo.getFrecuencia());
            stm.setFloat(6, vuelo.getPrecio_ruta());
            stm.setString(7, vuelo.getTiempo_estimado());
            
            stm.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println(e);
            return  null; 
        }
        return vuelo;
    }
    
    
    
    
    
    public empresaModel updateVuelo (empresaModel upVuelo) {
        ConexionBD con = new ConexionBD();
        String sql = "update empresa_de_aviacion set ciudad_salida=?,ciudad_llegada=?,fecha_salida=?,frecuencia=?,precio_ruta=?,tiempo_estimado=? where Id_vuelo =? ";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            stm.setString(1, upVuelo.getCiudad_salida());
            stm.setString(2, upVuelo.getCiudad_llegada());
            stm.setString(3, upVuelo.getFecha_salida());
            stm.setString(4, upVuelo.getFrecuencia());
            stm.setFloat(5, upVuelo.getPrecio_ruta());
            stm.setString(6, upVuelo.getTiempo_estimado());
            stm.setInt(7, upVuelo.getId_vuelo());
            
            stm.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println("Error al actualizar");
            return null;
        }
        return upVuelo;
    }
    
    
    
    
    
    
    public String deleteVuelo(String id){
        ConexionBD con = new ConexionBD();
        String sql = "delete from empresa_de_aviacion where Id_vuelo =? ";
        
        try {
            PreparedStatement stm = con.getConnection().prepareStatement(sql);
            stm.setString(1, id);
            stm.executeQuery();
             
        } catch (SQLException e) {
            System.out.println("Error al aliminar ");
            return "{\"Accion\":\"Error\"}";
        }
        return  "{\"Accion\":\"resgistro borrado\"}";
        
    }
    
    
}
